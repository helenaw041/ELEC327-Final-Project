/**
 * @file    phased_pwm.c
 * @brief   4-channel phase-shifted 40 kHz PWM on TIMA0 with ISR+DMA CCR reloads.
 *
 * Built on the confirmed-working TIMA0 init pattern (square_wave_test.c):
 *   - CCPD set to enable all 4 CC output pins        <- was MISSING in broken version
 *   - CCLKCTL clock gate opened                      <- was MISSING in broken version
 *   - ZACT=HIGH / CUACT=LOW using SDK named macros   <- broken version used raw values
 *   - CLKDIV = /4 (8 MHz timer) matching working code
 *
 * Phase shifting strategy:
 *   All 4 channels rise simultaneously at counter ZERO (ZACT=HIGH).
 *   Each channel falls at a different tick (CC match, CUACT=LOW).
 *   Phase offset is encoded as fall tick = phase_ticks + duty_ticks.
 *
 *   DMA reloads the CC registers on every ZERO ISR so phase changes
 *   from main() take effect within one period (25 us).
 *
 * Pin Mapping:
 *   PA8  (PINCM19, func 5) -> TIMA0_C0
 *   PA9  (PINCM20, func 5) -> TIMA0_C1
 *   PA7  (PINCM14, func 5) -> TIMA0_C2
 *   PA12 (PINCM34, func 6) -> TIMA0_C3
 *
 * Clock:
 *   BUSCLK = 32 MHz, CLKDIV = /4 -> 8 MHz timer clock
 *   LOAD = 199 -> period = 200 ticks = 40 kHz
 *
 * @device  MSPM0G3507
 */

#include <ti/devices/msp/msp.h>
#include <stdint.h>
#include <stdbool.h>
#include "delay.h"

/* =========================================================================
 * Configuration
 * ========================================================================= */

#define POWER_STARTUP_DELAY     16U

#define BUSCLK_HZ               32000000UL
#define TIMER_CLK_HZ            (BUSCLK_HZ / 4U)                          /* 8 MHz  */
#define PWM_FREQ_HZ             40000UL
#define PERIOD_TICKS            ((uint32_t)(TIMER_CLK_HZ / PWM_FREQ_HZ))  /* 200    */
#define ARR                     (PERIOD_TICKS - 1U)                        /* 199    */

#define DEFAULT_DUTY_PCT        50U
#define NUM_CH                  4U

/* =========================================================================
 * CCR table
 *
 * g_ccr_table[0..3] = fall ticks for CH0..CH3.
 * All channels rise at tick 0 (ZACT). Fall tick encodes phase+duty.
 * DMA writes these to CC_01[0..1] and CC_23[0..1] on every ZERO event.
 * ========================================================================= */

static volatile uint32_t g_ccr_table[4];

static volatile float   g_phase_deg[NUM_CH] = {0.0f, 90.0f, 180.0f, 270.0f};
static volatile uint8_t g_duty_pct = DEFAULT_DUTY_PCT;

/* =========================================================================
 * Math helpers
 * ========================================================================= */

static inline uint32_t degrees_to_ticks(float deg)
{
    while (deg >= 360.0f) deg -= 360.0f;
    while (deg <    0.0f) deg += 360.0f;
    return (uint32_t)((deg / 360.0f) * (float)PERIOD_TICKS);
}

static void recalculate_ccr_table(void)
{
    uint32_t duty_ticks = (PERIOD_TICKS * (uint32_t)g_duty_pct) / 100U;
    if (duty_ticks == 0U)           duty_ticks = 1U;
    if (duty_ticks >= PERIOD_TICKS) duty_ticks = PERIOD_TICKS - 1U;

    for (uint32_t ch = 0; ch < NUM_CH; ch++)
    {
        uint32_t phase = degrees_to_ticks(g_phase_deg[ch]);
        uint32_t fall  = (phase + duty_ticks) % PERIOD_TICKS;
        if (fall == 0U) fall = 1U;  /* CC=0 never fires on up-count */
        g_ccr_table[ch] = fall;
    }
}

/* =========================================================================
 * DMA bit field definitions
 * ========================================================================= */

#define DMACTL_DMASRCINCR_OFS        26U
#define DMACTL_DMADSTINCR_OFS        24U
#define DMACTL_DMADSTINCR_INC2       (2U << DMACTL_DMADSTINCR_OFS)
#define DMACTL_DMASRCINCR_INC2       (2U << DMACTL_DMASRCINCR_OFS)
#define DMACTL_DMADSTWIDTH_OFS       20U
#define DMACTL_DMASRCWIDTH_OFS       18U
#define DMACTL_DMADSTWIDTH_WORD      (2U << DMACTL_DMADSTWIDTH_OFS)
#define DMACTL_DMASRCWIDTH_WORD      (2U << DMACTL_DMASRCWIDTH_OFS)
#define DMACTL_DMAMODE_OFS           14U
#define DMACTL_DMAMODE_BLOCK         (1U << DMACTL_DMAMODE_OFS)
#define DMACTL_DMAEN                 (1U << 0U)

/* =========================================================================
 * GPIO Initialization
 * ========================================================================= */

static void GPIO_init(void)
{
    GPIOA->GPRCM.RSTCTL = (GPIO_RSTCTL_KEY_UNLOCK_W       |
                            GPIO_RSTCTL_RESETSTKYCLR_CLR   |
                            GPIO_RSTCTL_RESETASSERT_ASSERT);

    GPIOA->GPRCM.PWREN  = (GPIO_PWREN_KEY_UNLOCK_W |
                            GPIO_PWREN_ENABLE_ENABLE);

    delay_cycles(POWER_STARTUP_DELAY);

    IOMUX->SECCFG.PINCM[IOMUX_PINCM19] = (IOMUX_PINCM_PC_CONNECTED | 0x00000005U); /* PA8  C0 */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM20] = (IOMUX_PINCM_PC_CONNECTED | 0x00000005U); /* PA9  C1 */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM14] = (IOMUX_PINCM_PC_CONNECTED | 0x00000005U); /* PA7  C2 */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM34] = (IOMUX_PINCM_PC_CONNECTED | 0x00000006U); /* PA12 C3 */
}

/* =========================================================================
 * TIMA0 Initialization
 * ========================================================================= */

static void TIMA0_init(void)
{
    TIMA0->GPRCM.RSTCTL = (GPTIMER_RSTCTL_KEY_UNLOCK_W       |
                            GPTIMER_RSTCTL_RESETSTKYCLR_CLR   |
                            GPTIMER_RSTCTL_RESETASSERT_ASSERT);

    TIMA0->GPRCM.PWREN  = (GPTIMER_PWREN_KEY_UNLOCK_W |
                            GPTIMER_PWREN_ENABLE_ENABLE);

    delay_cycles(POWER_STARTUP_DELAY);

    /* 32 MHz / 4 = 8 MHz */
    TIMA0->CLKSEL = GPTIMER_CLKSEL_BUSCLK_SEL_ENABLE;
    TIMA0->CLKDIV = GPTIMER_CLKDIV_RATIO_DIV_BY_4;

    /* Up-count, continuous, start at 0, disabled until PhaseArray_Start() */
    TIMA0->COUNTERREGS.CTRCTL =
        GPTIMER_CTRCTL_REPEAT_REPEAT_1 |
        GPTIMER_CTRCTL_CM_UP           |
        GPTIMER_CTRCTL_CVAE_ZEROVAL    |
        GPTIMER_CTRCTL_EN_DISABLED;

    /* 200 ticks = 40 kHz */
    TIMA0->COUNTERREGS.LOAD = ARR;

    /*
     * ZACT=HIGH: all 4 pins go HIGH simultaneously at counter zero.
     * CUACT=LOW: pin goes LOW at CC match on up-count (fall edge).
     * Same config as confirmed-working single-channel code.
     */
    TIMA0->COUNTERREGS.CCACT_01[0] =
        GPTIMER_CCACT_01_ZACT_CCP_HIGH |
        GPTIMER_CCACT_01_CUACT_CCP_LOW;

    TIMA0->COUNTERREGS.CCACT_01[1] =
        GPTIMER_CCACT_01_ZACT_CCP_HIGH |
        GPTIMER_CCACT_01_CUACT_CCP_LOW;

    TIMA0->COUNTERREGS.CCACT_23[0] =
        GPTIMER_CCACT_01_ZACT_CCP_HIGH |
        GPTIMER_CCACT_01_CUACT_CCP_LOW;

    TIMA0->COUNTERREGS.CCACT_23[1] =
        GPTIMER_CCACT_01_ZACT_CCP_HIGH |
        GPTIMER_CCACT_01_CUACT_CCP_LOW;

    /* Load initial CC values */
    recalculate_ccr_table();

    TIMA0->COUNTERREGS.CC_01[0] = g_ccr_table[0];
    TIMA0->COUNTERREGS.CC_01[1] = g_ccr_table[1];
    TIMA0->COUNTERREGS.CC_23[0] = g_ccr_table[2];
    TIMA0->COUNTERREGS.CC_23[1] = g_ccr_table[3];

    /* Enable all 4 CC pins as outputs — CRITICAL, was missing in broken version */
    TIMA0->COMMONREGS.CCPD =
        GPTIMER_CCPD_C0CCP0_OUTPUT |
        GPTIMER_CCPD_C0CCP1_OUTPUT |
        GPTIMER_CCPD_C0CCP2_OUTPUT |
        GPTIMER_CCPD_C0CCP3_OUTPUT;

    /* Open clock gate — CRITICAL, was missing in broken version */
    TIMA0->COMMONREGS.CCLKCTL = GPTIMER_CCLKCTL_CLKEN_ENABLED;

    /* ZERO interrupt to trigger DMA reload */
    TIMA0->CPU_INT.IMASK = GPTIMER_CPU_INT_IMASK_Z_SET;

    NVIC_SetPriority(TIMA0_INT_IRQn, 0);
    NVIC_EnableIRQ(TIMA0_INT_IRQn);
}

/* =========================================================================
 * DMA Initialization
 *
 * CH0: g_ccr_table[0..1] -> CC_01[0..1]  (CH0, CH1 fall ticks)
 * CH1: g_ccr_table[2..3] -> CC_23[0..1]  (CH2, CH3 fall ticks)
 *
 * Both triggered from ZERO ISR every period.
 * ========================================================================= */

static void DMA_init(void)
{
    uint32_t ctl = DMACTL_DMASRCINCR_INC2   |
                   DMACTL_DMADSTINCR_INC2   |
                   DMACTL_DMASRCWIDTH_WORD  |
                   DMACTL_DMADSTWIDTH_WORD  |
                   DMACTL_DMAMODE_BLOCK     |
                   DMACTL_DMAEN;

    /* CH0: fall ticks for CH0,CH1 -> CC_01[0..1] */
    DMA->DMACHAN[0].DMACTL  = ctl;
    DMA->DMACHAN[0].DMASA   = (uint32_t)&g_ccr_table[0];
    DMA->DMACHAN[0].DMADA   = (uint32_t)&TIMA0->COUNTERREGS.CC_01[0];
    DMA->DMACHAN[0].DMASZ   = 2U;
    DMA->DMATRIG[0].DMATCTL = DMA_SOFTWARE_TRIG;

    /* CH1: fall ticks for CH2,CH3 -> CC_23[0..1] */
    DMA->DMACHAN[1].DMACTL  = ctl;
    DMA->DMACHAN[1].DMASA   = (uint32_t)&g_ccr_table[2];
    DMA->DMACHAN[1].DMADA   = (uint32_t)&TIMA0->COUNTERREGS.CC_23[0];
    DMA->DMACHAN[1].DMASZ   = 2U;
    DMA->DMATRIG[1].DMATCTL = DMA_SOFTWARE_TRIG;
}

/* =========================================================================
 * TIMA0 ISR — fires every 25 us on ZERO event
 * ========================================================================= */

void TIMA0_IRQHandler(void)
{
    uint32_t isr = TIMA0->CPU_INT.MIS;

    if (isr & GPTIMER_CPU_INT_MIS_Z_SET)
    {
        DMA->DMATRIG[0].DMATCTL = DMA_SOFTWARE_TRIG;
        DMA->DMATRIG[1].DMATCTL = DMA_SOFTWARE_TRIG;

        TIMA0->CPU_INT.ICLR = GPTIMER_CPU_INT_ICLR_Z_CLR;
    }
}

/* =========================================================================
 * Public API
 * ========================================================================= */

void PhaseArray_SetPhase(uint8_t channel, float phase_deg)
{
    if (channel >= NUM_CH) return;
    while (phase_deg >= 360.0f) phase_deg -= 360.0f;
    while (phase_deg <    0.0f) phase_deg += 360.0f;
    g_phase_deg[channel] = phase_deg;
    recalculate_ccr_table();
}

void PhaseArray_SetAllPhases(const float phases[NUM_CH])
{
    for (uint8_t ch = 0; ch < NUM_CH; ch++)
    {
        float deg = phases[ch];
        while (deg >= 360.0f) deg -= 360.0f;
        while (deg <    0.0f) deg += 360.0f;
        g_phase_deg[ch] = deg;
    }
    recalculate_ccr_table();
}

void PhaseArray_SetDuty(uint8_t duty_pct)
{
    if (duty_pct == 0U || duty_pct >= 100U) return;
    g_duty_pct = duty_pct;
    recalculate_ccr_table();
}

void PhaseArray_Init(void)
{
    GPIO_init();
    TIMA0_init();
    DMA_init();
}

void PhaseArray_Start(void)
{
    TIMA0->COUNTERREGS.CTRCTL |= GPTIMER_CTRCTL_EN_ENABLED;
}

void PhaseArray_Stop(void)
{
    TIMA0->COUNTERREGS.CTRCTL &= ~GPTIMER_CTRCTL_EN_ENABLED;

    IOMUX->SECCFG.PINCM[IOMUX_PINCM19] = (IOMUX_PINCM_PC_CONNECTED | 0x00000001U);
    IOMUX->SECCFG.PINCM[IOMUX_PINCM20] = (IOMUX_PINCM_PC_CONNECTED | 0x00000001U);
    IOMUX->SECCFG.PINCM[IOMUX_PINCM14] = (IOMUX_PINCM_PC_CONNECTED | 0x00000001U);
    IOMUX->SECCFG.PINCM[IOMUX_PINCM34] = (IOMUX_PINCM_PC_CONNECTED | 0x00000001U);

    GPIOA->DOUTCLR31_0 = (1U << 8) | (1U << 9) | (1U << 7) | (1U << 12);
    GPIOA->DOESET31_0  = (1U << 8) | (1U << 9) | (1U << 7) | (1U << 12);
}

/* =========================================================================
 * Example main()
 *
 * Beam steering:
 *   delta_phi (deg) = 180 * sin(theta)
 *   theta = 30 deg -> delta_phi = 90 deg
 * ========================================================================= */

int main(void)
{
    PhaseArray_Init();

    float phases[NUM_CH] = {0.0f, 90.0f, 180.0f, 270.0f};
    PhaseArray_SetAllPhases(phases);

    PhaseArray_Start();

    while (1)
    {
        __WFI();
    }
}
